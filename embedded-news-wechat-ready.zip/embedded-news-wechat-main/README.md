# embedded-news-wechat

基于现有公众号自动化流程改造的嵌入式软件技术文章生成项目。

## 当前行为

- 内容来源：DEV.to。
- 关注方向：STM32、MCU、嵌入式 C/C++、RTOS/FreeRTOS、外设驱动、嵌入式 Linux、调试工具与软硬件协同。
- AI：使用 SiliconFlow Chat Completions API 生成一篇中文技术文章。文章事实必须来自抓取到的原文材料。
- 微信：沿用现有 HTML 排版与草稿箱提交流程，配色调整为深青蓝与浅青蓝。
- 公众号当前临时名称：`web前端漫游记`，由 `WECHAT_AUTHOR` 配置；正式改名后再修改该值。
- 运行：工作流仅支持手动触发，验证稳定后再决定是否启用定时。
- 历史：独立保存到 ECS `/home/github-runner/data/embedded-news-wechat/processed_news.json`，与前端项目历史隔离。

## GitHub Actions Secrets

在本仓库的 Settings → Secrets and variables → Actions 中单独配置：

- `SILICONFLOW_API_KEY`
- `WECHAT_APP_ID`
- `WECHAT_APP_SECRET`

不要复制前端公众号的历史文件。请确认新公众号的 AppID、AppSecret 和 IP 白名单配置属于该公众号。

## 首次测试

1. 确认仓库绑定到正确的 ECS self-hosted runner。
2. 配置上述 Secrets。
3. 将有效的 JPEG 封面文件 `cover.jpg` 放到仓库根目录（文件需是真正的 JPEG，而不仅是扩展名 `.jpg`）。
4. 在 Actions 中手动运行 `Embedded News Manual Test`。
5. 查看日志中的候选文章、筛选结果和完整生成文章；随后确认微信草稿箱是否收到草稿。

首次成功之前不要添加定时计划。
